import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3001,
    proxy: {
      "/data": "http://localhost:8000",
      "/users": "http://localhost:8000",
    },
  },
});
